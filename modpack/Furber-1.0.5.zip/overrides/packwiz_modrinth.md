## packwiz modrinth

Manage modrinth-based mods

### Options

```
  -h, --help   help for modrinth
```

### Options inherited from parent commands

```
      --cache string              The directory where packwiz will cache downloaded mods (default "/home/faebian/.cache/packwiz/cache")
      --config string             The config file to use (default "/home/faebian/.config/packwiz/.packwiz.toml")
      --meta-folder string        The folder in which new metadata files will be added, defaulting to a folder based on the category (mods, resourcepacks, etc; if the category is unknown the current directory is used)
      --meta-folder-base string   The base folder from which meta-folder will be resolved, defaulting to the current directory (so you can put all mods/etc in a subfolder while still using the default behaviour) (default ".")
      --pack-file string          The modpack metadata file to use (default "pack.toml")
  -y, --yes                       Accept all prompts with the default or "yes" option (non-interactive mode) - may pick unwanted options in search results
```

### SEE ALSO

* [packwiz](packwiz.md)	 - A command line tool for creating Minecraft modpacks
* [packwiz modrinth add](packwiz_modrinth_add.md)	 - Add a project from a Modrinth URL, slug/project ID or search
* [packwiz modrinth export](packwiz_modrinth_export.md)	 - Export the current modpack into a .mrpack for Modrinth

